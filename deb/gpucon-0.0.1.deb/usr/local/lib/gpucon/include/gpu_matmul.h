
extern "C"
void gpu_matmul(double * h_x, double * h_res, size_t n, size_t p, int gpuID);

