
extern "C"
void gpu_matmul_div(double * h_x, double * h_y, double * h_res, double * h_x_sds, double * h_y_sds, size_t n, size_t px, size_t py, int gpuID);

