
extern "C" void gpu_div_by_sd(double * h_cors, double * h_sds, size_t n, size_t p, int gpuID);

extern "C" void gpu_tut_nix();

